Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='CATS' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
	    "ParamName=C_Category",
	    "RegExp=categories/(.*?)\">",
	    "Ordinal=All",
	    SEARCH_FILTERS,
	    "Scope=Body",
	    "IgnoreRedirections=No",
	    LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);
		
		lr_save_string(
    lr_paramarr_random("C_Category"),
    "SelectedCategory");



	lr_start_transaction("1_Launch");

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790815034021\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_concurrent_start(NULL);

	web_url("logo-topbar.gif", 
		"URL=https://jpetstore.aspectran.com/images/logo-topbar.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t2.inf", 
		LAST);

	web_url("splash.gif", 
		"URL=https://jpetstore.aspectran.com/images/splash.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t3.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_end_transaction("1_Launch",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("2_category");

/*Correlation comment - Do not change!  Original value='FL-DSH-01' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
	    "ParamName=C_Product",
	    "RegExp=products/(.*?)\">",
	    "Ordinal=All",
	    SEARCH_FILTERS,
	    "Scope=Body",
	    "IgnoreRedirections=No",
	    LAST);

	web_url("Cats",
	    "URL=https://jpetstore.aspectran.com/categories/{SelectedCategory}",
	    "Resource=0",
	    "RecContentType=text/html",
	    "Referer=https://jpetstore.aspectran.com/",
	    "Snapshot=t4.inf",
	    "Mode=HTTP",
	    LAST);
	    
	    lr_save_string(
    lr_paramarr_random("C_Product"),
    "SelectedProduct");

	lr_end_transaction("2_category",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("3_product");

/*Correlation comment - Do not change!  Original value='EST-34' Name ='C_Item' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Item",
		"RegExp=items/(.*?)\">",
		"Ordinal=All",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Product",
	    "URL=https://jpetstore.aspectran.com/products/{SelectedProduct}",
	    "Resource=0",
	    "RecContentType=text/html",
	    "Referer=https://jpetstore.aspectran.com/categories/{SelectedCategory}",
	    "Snapshot=t5.inf",
	    "Mode=HTTP",
	    LAST);
	    
	    lr_save_string(
    lr_paramarr_random("C_Item"),
    "SelectedItem");

	lr_end_transaction("3_product",LR_AUTO);

	lr_think_time(11);

	lr_start_transaction("4_Item");

	web_url("Item",
	    "URL=https://jpetstore.aspectran.com/products/{SelectedProduct}/items/{SelectedItem}",
	    "Resource=0",
	    "RecContentType=text/html",
	    "Referer=https://jpetstore.aspectran.com/products/{SelectedProduct}",
	    "Snapshot=t6.inf",
	    "Mode=HTTP",
	    LAST);

	web_url("cat2.gif",
		"URL=https://jpetstore.aspectran.com/images/cat2.gif",
		"Resource=1",
		"RecContentType=image/gif",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{SelectedItem}",
		"Snapshot=t7.inf",
		LAST);

	lr_end_transaction("4_Item",LR_AUTO);

	lr_start_transaction("5_Add to cart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={SelectedItem}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{SelectedItem}",
		"Snapshot=t8.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_Add to cart",LR_AUTO);

	lr_start_transaction("6_checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_checkout",LR_AUTO);

	lr_start_transaction("7_login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={P_UserName}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		LAST);

	web_url("banner_dogs.gif", 
		"URL=https://jpetstore.aspectran.com/images/banner_dogs.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t11.inf", 
		LAST);

	lr_end_transaction("7_login",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("8_continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value={P_creditCard}", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value=10001", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_continue",LR_AUTO);

	lr_start_transaction("9_confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_confirm",LR_AUTO);

	return 0;
}